using UnityEngine;
using System.Collections;
using System.Collections.Generic;

using PathFinding;

public class GridCell : Node 
{
	public GridCell(int i):base(i) {
		// TO IMPLEMENT
	}
	public GridCell(GridCell n):base(n) {
		// TO IMPLEMENT
	}

	// Your class that represents a grid cell node derives from Node

	// You add any data needed to represent a grid cell node

	// EXAMPLE DATA
	/*
	protected float xMin;
	protected float xMax;
	protected float zMin;
	protected float zMax;

	protected bool occupied;

	protected Vector3 center;
	*/

	// You also add any constructors and methods to implement your grid cell node class

	// TO IMPLEMENT
};
