using UnityEngine;

public class Agent : MonoBehaviour
{
    public float velocity;
    public float radius;
    public Vector3 targetPosition;
}
